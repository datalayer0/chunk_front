import {trustwallet} from './trustwallet';
import {metadata} from './metadata';

export const api = {
  trustwallet,
  metadata,
};
