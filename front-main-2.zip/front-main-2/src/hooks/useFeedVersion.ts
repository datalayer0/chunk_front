import {useMemo} from 'react';
import {useParams} from 'react-router-dom';
import {Version} from 'src/types/Asset';

export const useFeedVersion = () => {
  const {version} = useParams<{version: Version}>();

  return useMemo(() => version || 'v1', [version]);
};
