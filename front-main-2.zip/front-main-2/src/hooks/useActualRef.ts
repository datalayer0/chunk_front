import {useRef} from 'react';

/** Returns react ref, that always stores the actual value (last passed) */
export const useActualRef = <T>(value: T) => {
  const ref = useRef<T>(value);
  ref.current = value;
  return ref;
};
