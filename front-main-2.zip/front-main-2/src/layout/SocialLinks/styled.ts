import {breakpoint} from 'src/components/UI/theme';
import styled from 'styled-components';

export const Links = styled.div`
  font-size: 3rem;
  margin-bottom: 2rem;
  @media (min-width: ${breakpoint.tablet}) {
    margin-bottom: 0;
  }
  img {
    width: 3rem;
  }
  a {
    color: inherit;
    text-decoration: none;
    font-weight: bold;
    :hover {
      text-decoration: underline;
    }
    :not(:last-child) {
      margin-right: 3rem;
    }
  }
`;
