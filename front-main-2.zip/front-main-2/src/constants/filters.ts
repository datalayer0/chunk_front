export type FiltersTypes =
  | 'All'
  | 'Token'
  | 'Stable'
  | 'Uni V2 LP'
  | 'Sushi LP'
  | 'Compound'
  | 'Yearn Vaults'
  | '3CRV';

export type Filter = {
  label: FiltersTypes;
  onClick: () => void;
  disable: boolean;
};

export const getFilters = (setFilterByType: (filterType: FiltersTypes) => void): Filter[] => [
  {
    label: 'All',
    onClick: () => {
      setFilterByType('All');
    },
    disable: false,
  },
  {
    label: 'Token',
    onClick: () => {
      setFilterByType('Token');
    },
    disable: false,
  },
  {
    label: 'Stable',
    onClick: () => {
      setFilterByType('Stable');
    },
    disable: false,
  },
  {
    label: 'Uni V2 LP',
    onClick: () => {
      setFilterByType('Uni V2 LP');
    },
    disable: false,
  },
  {
    label: 'Sushi LP',
    onClick: () => {
      setFilterByType('Sushi LP');
    },
    disable: false,
  },
  {
    label: 'Compound',
    onClick: () => {
      setFilterByType('Compound');
    },
    disable: false,
  },
  {
    label: 'Yearn Vaults',
    onClick: () => {
      setFilterByType('Yearn Vaults');
    },
    disable: false,
  },
  {
    label: '3CRV',
    onClick: () => {
      setFilterByType('3CRV');
    },
    disable: false,
  },
];
