import styled from 'styled-components';
import {color} from '../theme';
import {ButtonDefaultStyles} from '../UiButton/styled';

export const StyledLink = styled.a<{asButton?: boolean}>`
  color: ${color.darkBlack};
  font-size: 4rem;
  font-weight: bold;
  ${(p) => (p.asButton ? ButtonDefaultStyles : '')}
`;
