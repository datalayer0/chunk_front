import React, {AnchorHTMLAttributes} from 'react';
import {StyledLink} from './styled';

export const UiLink: React.FC<AnchorHTMLAttributes<HTMLAnchorElement> & {asButton?: boolean}> = (
  props,
) => <StyledLink {...props} />;
