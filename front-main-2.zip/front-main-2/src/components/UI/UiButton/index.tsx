import React, {ButtonHTMLAttributes} from 'react';
import {StyledButton} from './styled';
import {BtnProps} from './types';

export const UiButton: React.FC<ButtonHTMLAttributes<HTMLButtonElement> & BtnProps> = (props) => (
  <StyledButton {...props} />
);
