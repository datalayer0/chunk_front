export type BtnColor = 'gray' | 'green';

export interface BtnProps {
  color: BtnColor;
  active?: boolean;
  size?: 'small' | 'normal' | undefined;
}
