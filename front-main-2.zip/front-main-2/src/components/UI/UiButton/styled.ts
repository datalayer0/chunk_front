import styled, {css} from 'styled-components';
import {BtnProps} from './types';
import {color} from '../theme';

export const ButtonDefaultStyles = css`
  padding: 0.9em 1.6em 0.8em;
  border-radius: 0.8em;
  font-size: 2rem;
  border: none;
  box-shadow: none;
  font-weight: bold;
  cursor: pointer;
  background: ${color.grey};
  text-decoration: none;
  color: ${color.darkBlack};
  text-transform: capitalize;
`;

export const StyledButton = styled.button<BtnProps>`
  ${ButtonDefaultStyles};
  ${(p) => {
    if (p.size === 'small') return 'padding: 0.9em 1.6em 0.8em;';
    else return 'padding: 0.6em 1em 0.5em;';
  }}
  background: ${(p) => {
    if (p.active) {
      if (p.color === 'gray') return color.grey;
      return color.darkBlack;
    }
    if (p.color === 'gray') return color.grey;
    return color.green;
  }};
  ${(p) => (p.active ? 'color: #fff;' : '')}
  :hover {
    background: ${(p) => (p.color === 'gray' ? color.grey : color.darkBlack)};
    color: ${(p) => (p.color === 'gray' ? 'inherit' : '#fff')};
  }
`;
