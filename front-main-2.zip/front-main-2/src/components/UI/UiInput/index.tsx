import React, {InputHTMLAttributes} from 'react';
import {StyledInput} from './styled';

export const UiInput: React.FC<InputHTMLAttributes<HTMLInputElement>> = (props) => (
  <StyledInput {...props} />
);
