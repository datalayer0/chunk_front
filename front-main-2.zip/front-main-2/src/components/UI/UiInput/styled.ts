import styled from 'styled-components';
import {color} from '../theme';

export const StyledInput = styled.input`
  width: 100%;
  padding: 2rem 2.5rem;
  font-size: 2rem;
  font-weight: 500;
  border: 0.125rem solid ${color.black};
  background: ${color.white};
  border-radius: 0;
  text-transform: capitalize;
  :placeholder {
    color: ${color.gray};
  }
`;
