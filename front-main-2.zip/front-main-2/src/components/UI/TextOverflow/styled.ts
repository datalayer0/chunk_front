import styled from 'styled-components';

export const TextContainer = styled.div`
  display: flex;
`;

export const LeftPart = styled.div`
  flex: 0 1 auto;
  overflow: hidden;
  text-overflow: ellipsis;
`;

export const RightPart = styled.div`
  flex: 1 0 auto;
  overflow: hidden;
`;
