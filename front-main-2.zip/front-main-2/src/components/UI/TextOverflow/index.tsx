import {LeftPart, RightPart, TextContainer} from './styled';

export const TextOverflow: React.FC<{text: string}> = ({text}) => {
  const splitIndex = Math.round(text.length * 0.9);
  const leftPart = text.slice(0, splitIndex);
  const rightPart = text.slice(splitIndex);

  return (
    <TextContainer>
      <LeftPart>{leftPart}</LeftPart>
      <RightPart>{rightPart}</RightPart>
    </TextContainer>
  );
};
