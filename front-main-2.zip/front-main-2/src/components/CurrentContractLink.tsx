import React from 'react';
import {LINKS} from 'src/constants/staticValues';
import {ChainName} from '../types/MetadataApi';
import {UiLink} from './UI/UiLink';

export const CurrentContractLink: React.FC<{
  contractAddress: string;
  currentChainId: ChainName;
}> = ({contractAddress, currentChainId}) => {
  const getContractLink = (chainId: ChainName, address: string) => {
    switch (chainId) {
      case 'bsc':
        return `https://bscscan.com/address/${address}`;
      case 'xdai':
        return `https://blockscout.com/xdai/mainnet/address/${address}`;
      case 'polygon':
        return `https://polygonscan.com/address/${address}`;
      case 'optimism':
        return `https://optimistic.etherscan.io/address/${address}`;
      case 'fantom':
        return `https://ftmscan.com/address/${address}`;
      case 'avalanche':
        return `https://snowtrace.io/address/${address}`;
      case 'harmony':
        return `https://explorer.harmony.one/address/${address}`;
      case 'heco':
        return `https://hecoinfo.com/address/${address}`;
      case 'oasis':
        return `https://explorer.emerald.oasis.dev/address/${address}`;
      case 'arbitrum':
        return `https://arbiscan.io/address/${address}`;
      case 'syscoin':
        return `https://explorer.syscoin.org/address/${address}`;
      case 'boba':
        return `https://blockexplorer.boba.network/address/${address}`;
      case 'okex':
        return `https://www.oklink.com/en/okc/address/${address}`;
      case 'moonriver':
        return `https://moonriver.moonscan.io/address/${address}`;
      case 'moonbeam':
        return `https://moonscan.io/address/${address}`;
      case 'celo':
        return `https://explorer.celo.org/address/${address}`;
      case 'clover':
        return `https://clvscan.com/address/${address}`;
      case 'bittorrent':
        return `https://bttcscan.com/address/${address}`;
      case 'cronos':
        return `https://cronoscan.com/address/${address}`;
      case 'klaytn':
        return `https://scope.klaytn.com/address/${address}`;
      case 'aurora':
        return `https://aurorascan.dev/address/${address}`;
      case 'dogechain':
        return `https://explorer.dogechain.dog/address/${address}`;
      case 'etc':
        return `https://blockscout.com/etc/mainnet/address/${address}`;
      case 'bobhub':
        return `${LINKS.explorer}/address/${address}`;
      default: {
        return `/${address}`;
      }
    }
  };

  return (
    <UiLink
      target="_blank"
      rel="noreferrer"
      href={getContractLink(currentChainId, contractAddress)}
    >
      {contractAddress.slice(0, 4)}...{contractAddress.slice(-4)}
    </UiLink>
  );
};
