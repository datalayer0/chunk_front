import styled from 'styled-components';

export const SubTitle = styled.h4`
  margin: 0 0 2rem;
  font-size: 4rem;
  font-weight: 700;
`;
