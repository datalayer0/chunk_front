export interface TrustwalletToken {
  asset: string;
  type: string;
  address: string;
  name: string;
  symbol: string;
  decimals: number;
  logoURI: string;
  pairs: [];
}

export interface TrustwalletTokenList {
  name: string;
  logoURI: string;
  timestamp: string;
  tokens: TrustwalletToken[];
}
