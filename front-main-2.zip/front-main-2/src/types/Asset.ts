import {ChainMetadata, ChainName} from './MetadataApi';

export type AssetType = 'tokens' | 'stocks' | 'bonds' | 'currencies' | 'commodities';
export type Version = 'v1' | 'v2';

export type AssetsStoreMap = {
  [version in Version]: {
    [chainName in ChainName]: {
      [key in AssetType]?: ChainMetadata;
    };
  };
};
