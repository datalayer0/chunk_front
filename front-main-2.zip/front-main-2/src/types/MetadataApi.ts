export type ChainName =
  | 'fantom'
  | 'bsc'
  | 'xdai'
  | 'polygon'
  | 'optimism'
  | 'oasis'
  | 'avalanche'
  | 'harmony'
  | 'arbitrum'
  | 'heco'
  | 'syscoin'
  | 'boba'
  | 'okex'
  | 'moonriver'
  | 'moonbeam'
  | 'celo'
  | 'clover'
  | 'bittorrent'
  | 'cronos'
  | 'aurora'
  | 'dogechain'
  | 'etc'
  | 'bobhub'
  | 'klaytn'
  | 'linea';

export interface ChainAsset {
  address: string;
  price: string;
  symbol: string;
  updated: number;
  sources: string[];
  metric: {
    name: string;
    currency: string;
    description: string;
    tags: string[];
  } | null;
  multiparty: Omit<Multiparty, 'prices'> & {
    prices: Record<string, string>;
  };
}

export type Multiparty = {
  participants: string[];
  quorum: number;
  signers: string[];
  prices: Record<string, Record<string, string>>;
};

export interface ChainMetadata {
  updated: number;
  address: string;
  provider: ChainName;
  assets: ChainAsset[];
  multiparty?: Multiparty;
}

export type MetadataApi = ChainMetadata[];
