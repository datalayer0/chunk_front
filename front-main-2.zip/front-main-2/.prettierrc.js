module.exports = {
  tabWidth: 2,
  trailingComma: 'all',
  singleQuote: true,
  arrowParens: 'always',
  jsxBracketSameLine: false,
  bracketSpacing: false,
  printWidth: 100,
};
